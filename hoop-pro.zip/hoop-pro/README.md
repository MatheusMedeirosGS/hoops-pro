Site Institucional – Hoops Pro - Produtos e Serviços Relacionados Ao Mundo Hooper

O projeto consiste no desenvolvimento de um site institucional para a Alpha Nutri, empresa especializada em suplementos alimentares, vitaminas, produtos naturais e serviços de orientação nutricional. O objetivo do site é apresentar a marca, destacar seus produtos e serviços,
reforçar credibilidade no mercado e facilitar o contato entre clientes e a empresa, utilizando HTML, CSS e Bootstrap para criar uma página moderna, responsiva e alinhada à identidade visual da empresa.

Matheus Gabriel de Medeiros Silva

1° Periodo em Analise e desenvolvimento de sistemas.

https://pedro-soares09.github.io/alpha_nutri/

